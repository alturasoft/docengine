---
sigla: CRI
empresa: CREDINFORM INTERNATIONAL S.A
version: 6
estado: activo
ultima_revision: 2026-09-02
---

## Descripción

Reglas de extracción para pólizas de **Credinform International S.A.**

Este skill extiende las reglas base del `skill-general.md` integrando los hallazgos de extracción, principios de integridad numérica, alineación tabular implícita (borderless), bloqueo de filas multilínea (row-locking), soporte para encabezados multinivel en tablas de baremos/invalidez, prevención de truncamiento OCR y validación contextual geográfica en listas regionales de talleres.

## Reglas de Post-Procesado

```yaml
kv_keys:
  - Póliza
  - Poliza
  - Póliza Nro.
  - Póliza Nro
  - Nro. de Póliza
  - N° de Póliza
  - Número de Póliza
  - Asegurado
  - Tomador
  - Contratante
  - Dirección
  - Direccion
  - Zona
  - Teléfono
  - Telefono
  - E-mail
  - Email
  - Celular
  - Nro. NIT
  - NIT
  - Actividad
  - Distrito
  - Ciudad
  - Plaza de Circulación
  - Plaza de Circulacion
  - Propiedad
  - Cilindrada
  - Placa
  - Marca
  - Modelo
  - Año
  - Color
  - Chasis
  - Motor
  - Tipo de Vehículo
  - Tipo de Vehiculo
  - Uso
  - Valor Asegurado
  - Suma Asegurada
  - Franquicia
  - Deducible
  - Prima Total
  - Prima Neta

header_patterns:
  # Dirección Oficina Principal / Sucursal 1
  - 'Calacoto Calle Julio Patiño'
  - 'Calle Capitan Ravelo Nro\.?\s*2328'
  - 'OFICINA (PRINCIPAL|CENTRAL)'
  - 'SUCURSAL\s*1'
  # Contactos institucionales (Piloto, Fax, Email, Ciudad)
  - 'Central Piloto:?\s*\(?0?2\)?\s*2775550'
  - 'Fax:\s*\(?591-02\)?\s*2203917'
  - 'credinformsa@credinformsa\.com'
  - 'La Paz\s*-\s*Bolivia'
  # Teléfonos de sucursales regionales (Telf: (02)..., Telf: (03)..., Telf: (04)...)
  - 'Telf:\s*\(0[234]\)\d+'
  # Nombres de ciudades/sucursales aisladas extraídas del pie de página
  - '^(OFICINA PRINCIPAL|SUCURSAL 1|SANTA CRUZ|COCHABAMBA|SUCRE|POTOSI|ORURO|TARIJA|CAMIRI|YACUIBA|TRINIDAD)$'
  # Encabezados de póliza y metadatos repetitivos por página
  - 'SERVICIOS PETROLEROS PONEX S\.R\.L CAC-SCE0651635'
  - 'SERVICIOS PETROLEROS PONEX S\.R\.L\s+CAC-[A-Z0-9]+'
  - 'Asegurado:\s*\|\s*\|\s*\|\s*\|'
  - '^\|\s*Asegurado:\s*\|\s*\|\s*\|\s*\|\s*$'
  - '^P[áa]gina\s+\d+\s+de\s+\d+$'

table_split_hints:
  - "CONDICIONES PARTICULARES"
  - "CONDICIONES GENERALES"
  - "CUADRO DE COBERTURAS"
  - "DATOS DEL ASEGURADO"
  - "DATOS TECNICOS DEL VEHICULO"
  - "DATOS TÉCNICOS DEL VEHÍCULO"
  - "INVALIDEZ PERMANENTE"
  - "LISTA DE TALLERES"

normalize_dates: false
currency_fields:
  - Valor Asegurado
  - Suma Asegurada
  - Franquicia
  - Deducible
  - Prima Total
  - Prima Neta

# -------------------------------------------------------------------
# Identificación de metadatos de póliza en encabezados repetitivos
# -------------------------------------------------------------------
header_metadata_patterns:
  - id: cri_header_policy_identification
    description: >-
      Identifica en los encabezados repetitivos de páginas escaneadas el número de póliza,
      el tomador y/o el asegurado para consolidar la información básica de la póliza.
    patterns:
      numero_poliza:
        - 'P[ÓO]LIZA(?:\s*(?:NRO\.?|N°|NO\.?|:))?\s*([A-Z0-9\-\/]+)'
        - 'CAC\-[A-Z0-9]+'
      tomador:
        - 'TOMADOR(?:\s*[:\-])?\s*([A-Z0-9\.\,\s\-\&]+)'
        - 'CONTRATANTE(?:\s*[:\-])?\s*([A-Z0-9\.\,\s\-\&]+)'
      asegurado:
        - 'ASEGURADO(?:\s*[:\-])?\s*([A-Z0-9\.\,\s\-\&]+)'

# -------------------------------------------------------------------
# Reglas de limpieza y corrección de celdas de tablas (Tabular Leakage / OCR)
# -------------------------------------------------------------------
table_cell_cleanup_rules:
  # Sub-tarea A: Eliminación de Prefijos Basura en Celdas de Nombres
  - id: cri_clean_table_name_prefixes
    description: >-
      Remueve índices numéricos y caracteres residuales de escaneo (ej. '1 .- ,', '3 .- ,')
      al inicio de celdas de texto limpio en tablas de asegurados.
    pattern: '(\|\s*)\d+\s*\.?\s*-\s*,\s*'
    replacement: '\1'

  # Sub-tarea B: Separación de Mezcla de Columnas y Sufijos de Tasas ('NT') en C.I.
  - id: cri_clean_ci_suffix_nt
    description: >-
      Remueve el sufijo flotante 'NT' y prefijos redundantes 'CI.' en celdas de documento
      de identidad, dejando únicamente el identificador numérico limpio.
    pattern: '(\|\s*)(?:CI\.?\s*)?(\d+)\s+NT(\s*\|)'
    replacement: '\1\2\3'

  # Sub-tarea C: Corrección de truncamiento y ruido OCR en talleres y nombres propios
  - id: cri_clean_ocr_truncation_talleres_and_names
    description: >-
      Corrige truncamientos y errores OCR comunes en celdas de talleres, proveedores y asegurados.
    pattern: '(\|\s*)SERVICICO MECANIC(\s*\|)'
    replacement: '\1Servicios Mecánicos\2'

  - id: cri_clean_ocr_truncation_caballero
    description: >-
      Corrige truncamiento de nombre en celdas de propietario/asegurado.
    pattern: '(\|\s*)ANDR[EÉ]S CABALLE(\s*\|)'
    replacement: '\1Andrés Caballero\2'

  - id: cri_clean_ocr_truncation_punto_axzo
    description: >-
      Corrige truncamiento de nombre comercial de centros o talleres.
    pattern: '(\|\s*)Punto Axz(\s*\|)'
    replacement: '\1Punto Axzo\2'

  # Sub-tarea D: Separación de email y celular fusionados en celdas borderless
  - id: cri_clean_email_celular_split
    description: >-
      Separa valores de email y celular combinados accidentalmente en una sola celda.
    pattern: '(\|\s*[\w\.\-]+@[\w\.\-]+\.[a-zA-Z]{2,})\s+(\d{7,8})(\s*\|)'
    replacement: '\1 | \2\3'

# -------------------------------------------------------------------
# Corrección de alineación de columnas y desfaces en tablas CRI
# -------------------------------------------------------------------
table_column_alignment_fixes:
  - id: fix_invalidez_multinivel_cri
    description: >-
      Reconstruye la tabla de baremo de Invalidez Permanente Parcial de Miembros Superiores
      con subcolumnas Dominante (%) y No Dominante (%) asegurando la correcta alineación.
    header_pattern: ["Pérdida", "Dominante (%)", "No Dominante (%)"]
    expected_columns: 3

  - id: fix_asegurado_tomador_borderless_cri
    description: >-
      Asegura la estructura unificada de 3 columnas para secciones contiguas de Asegurado y Tomador.
    header_pattern: ["Campo", "Datos Asegurado", "Datos Tomador"]
    expected_columns: 3
```

## Directivas de Extracción Estructural y Semántica para CRI (Table-Aware & Layout-Aware Docling Engine)

### 1. Reglas Generales de Procesamiento Estructural
- **Principio de Integridad Numérica y No Regresión:** Ningún valor monetario, porcentaje, franquicia, deducible o prima presente en el PDF original de Credinform puede ser omitido, redondeado o desplazado entre celdas. Se debe garantizar siempre la precisión exacta a dos decimales (ej. `4,439.61`, `177,584.40`, `210,000.00`).
- **Asociación Estricta Fila-Columna en el Eje Y:** Toda celda de cobertura, beneficio o condición técnica debe conservar estrictamente su alineación horizontal con su respectivo valor numérico, límite o franquicia.

---

### 2. Instrucciones Específicas basadas en Análisis de Fallos de Extracción

#### REGLA 1: Detección y Alineación de Tablas Implícitas sin Bordes (Layout-Aware Borderless Grid)
- **Contexto del problema:** En las secciones de **Datos del Asegurado, Tomador** y **Datos Técnicos del Vehículo**, los documentos de Credinform no incluyen líneas divisorias o cuadrículas visibles. Docling suele detectar estas áreas como micro-tablas de 1 o 2 celdas con valores flotantes fuera de ellas, o aplana el texto perdiendo la correspondencia clave-valor.
  *Ejemplos de errores detectados:*
  - Celdas mezcladas en datos de contacto: `| **E-mail** | - | jsteer@ag.com.bo 70059881`, dejando el campo celular huérfano o vacío.
  - Encabezados contiguos colapsados en una sola celda: `CILINDRADA PLACA PROPIEDAD PLAZA DE CIRCULACION` con valores huérfanos listados abajo sin correspondencia de columna.
- **Instrucción de corrección:**
  1. Cuando se identifiquen bloques de datos clave-valor alineados en columnas implícitas (sin bordes físicos), no generar múltiples micro-tablas desconectadas ni listados planos de texto.
  2. Proyectar una grilla virtual basada en la alineación horizontal (coordenadas Y) y vertical (coordenadas X) del texto.
  3. Si existen datos contiguos de un Asegurado (columna izquierda) y un Tomador (columna derecha) en la misma fila horizontal, consolidarlos en una **única tabla unificada de 3 columnas**:
     ```markdown
     | Campo / Atributo | Datos Asegurado | Datos Tomador |
     | --- | --- | --- |
     | Nombre / Razón Social | SERVICIOS PETROLEROS PONEX S.R.L | SERVICIOS PETROLEROS PONEX S.R.L |
     | NIT / C.I. | 1028374029 | 1028374029 |
     | Dirección | Av. Principal Nro 123 | Av. Principal Nro 123 |
     | Teléfono / Celular | 70059881 | 70059881 |
     | E-mail | jsteer@ag.com.bo | jsteer@ag.com.bo |
     ```
  4. Para los **Datos Técnicos del Vehículo**, queda prohibido agrupar etiquetas de encabezados de columnas contiguas en una sola celda. Mapear cada atributo a su respectiva columna en la grilla virtual:
     ```markdown
     | Cilindrada | Placa | Propiedad | Plaza de Circulación |
     | --- | --- | --- | --- |
     | 2500 cc | 4059-XYZ | Particular | Santa Cruz |
     ```

#### REGLA 2: Bloqueo de Fila en Texto Multilínea contra Desplazamiento Vertical (Row-Locking & Text-Wrap Grid Merge)
- **Contexto del problema:** En el **Cuadro de Coberturas, Límites y Franquicias** (Secciones I a V), las descripciones de cobertura suelen ser extensas y abarcar varios renglones (text-wrap). El extractor interpreta erróneamente cada salto de línea como una nueva fila de la tabla, provocando que los datos numéricos (tasas, franquicias, valores asegurados) de las columnas derechas se desplacen verticalmente (grid shifting), asignando montos a coberturas equivocadas.
  *Ejemplos del error detectado:*
  - En la Sección I, el valor asegurado de `177,584.40` se desplazó a la columna de Franquicia `%` como `177,584.4`.
  - En la Sección III de Responsabilidad Civil, el límite de `210,000.00` se cortó y se mezcló con los límites de daños propios.
- **Instrucción de corrección:**
  1. Al extraer tablas de varias columnas, si el texto de una celda de descripción de cobertura se divide en varias líneas físicas dentro de la misma celda visual, fusionar (*merge*) todos los renglones en una **única celda de texto continuo en Markdown** separada por espacios o `<br>`.
  2. Queda estrictamente prohibido abrir una nueva fila de tabla `|` para renglones secundarios descriptivos si no existen nuevos valores numéricos correspondientes en las columnas derechas de esa misma fila.
  3. Todas las columnas de una fila deben mantenerse rígidamente bloqueadas en su eje Y original (*Row-Locking*).
  *Salida esperada:*
  ```markdown
  | Sección | Cobertura / Descripción | Valor Asegurado | Límite Máximo | Franquicia |
  | --- | --- | --- | --- | --- |
  | Sección I | Daños Propios por Accidente, Vuelco, Choque, Incendio y Robo Total o Parcial del Vehículo Asegurado | 177,584.40 | Según Valor Comercial | 10% mínimo $us 150 |
  | Sección III | Responsabilidad Civil hacia Terceros (Consecuencia de Daños Materiales y Corporales) | - | 210,000.00 | Sin Franquicia |
  ```

#### REGLA 3: Reconstrucción de Encabezados Jerárquicos Secundarios Multinivel (Multi-Level Headers - Sección VII Invalidez)
- **Contexto del problema:** En la tabla de **Invalidez Permanente Parcial de Miembros Superiores** (baremo de accidentes personales), existe un encabezado jerárquico dividido: una columna principal de "Pérdida / Lesión" y dos subcolumnas numéricas: "Dominante (%)" y "No Dominante (%)". El motor no asociaba los porcentajes con sus respectivas columnas, convertía la primera fila ("Anquilosis del hombro...") en un encabezado Markdown aislado y rompía la correspondencia de los incisos posteriores.
- **Instrucción de corrección:**
  1. Al detectar tablas comparativas o baremos de indemnización con columnas divididas por categoría, identificar la jerarquía de las cabeceras.
  2. Estructurar la tabla Markdown con los encabezados del nivel más bajo en la primera fila de la tabla:
     `| Pérdida / Lesión | Dominante (%) | No Dominante (%) |`
  3. Colocar cualquier título de categoría superior inmediatamente arriba como encabezado Markdown o texto en negrita:
     ```markdown
     ### Sección VII: Invalidez Permanente Parcial - Miembros Superiores

     | Pérdida / Lesión | Dominante (%) | No Dominante (%) |
     | --- | --- | --- |
     | Anquilosis del hombro en posición no funcional | 40% | 30% |
     | Anquilosis del codo en flexión completa | 35% | 25% |
     | Pérdida total del pulgar | 25% | 20% |
     ```
  4. Ningún inciso de lesión debe convertirse en encabezado Markdown ni romper la continuidad de la tabla.

#### REGLA 4: Prevención de Truncamiento de Bordes OCR y Limpieza Contextual de Diccionario (OCR Padding & Dictionary Cleanup)
- **Contexto del problema:** En tablas densas (listas de talleres, centros médicos o límites de auxilio mecánico), las letras finales o iniciales de nombres, empresas y direcciones se pierden debido a un recuadro de recorte (*bounding box*) demasiado ajustado o truncamiento del TableFormer.
  *Ejemplos detectados:*
  - `SERVICICO MECANIC` en lugar de `Servicios Mecánicos`.
  - `ANDRÉS CABALLE` en lugar de `Andrés Caballero`.
  - `Punto Axz` en lugar de `Punto Axzo`.
  - Valores monetarios truncados: `4,439.6` en vez de `4,439.61`.
- **Instrucción de corrección:**
  1. Aplicar un margen de expansión (*padding* horizontal de al menos 3-5 píxeles) a las cajas de detección de texto de cada celda para evitar la pérdida de caracteres en los bordes.
  2. Implementar paso de validación contextual mediante diccionario de seguros: si una palabra del ramo de automotores, talleres o nombres propios queda truncada (ej. `CABALLE` al final de la celda de propietario), corregirla contextualmente con el término completo (`CABALLERO`).
  3. Las cifras monetarias no deben redondearse ni perder decimales; preservar siempre la precisión completa a dos decimales (`4,439.61`).

#### REGLA 5: Validación Contextual y Corrección de Metadatos Geográficos (Contextual Metadata Cross-Check - Talleres Regionales Sucre / Oruro / Bolivia)
- **Contexto del problema:** En las páginas de talleres de Credinform, el PDF original presenta un error físico de diseño: los talleres de **Sucre** están ubicados bajo la cabecera superior de la página que dice "ORURO". Guiarse ciegamente por la estructura visual lineal duplicó el título de Oruro y agrupó los talleres de Sucre bajo el departamento equivocado.
- **Instrucción de corrección:**
  1. No confiar ciegamente en el encabezado de página (*header*) superior para clasificar sub-tablas regionales.
  2. Analizar el contenido semántico de las columnas "Dirección", "Zona" y "Teléfono" de las filas de la tabla.
  3. Cruzar contra la base geográfica de prefijos y zonas de Bolivia:
     - **Sucre / Chuquisaca:** Prefijo telefónico `64-`, zonas/calles: *Barrio San José*, *Jaime Mendoza*, *Calle Calvo*, *Calle Loa*, *Sucre*.
     - **La Paz:** Prefijo `2-` o `02-`, zonas: *Calacoto*, *Miraflores*, *San Pedro*, *Sopocachi*, *El Alto*.
     - **Santa Cruz:** Prefijo `3-` o `03-`, zonas: *Equipetrol*, *Radial 17*, *Parque Industrial*, *Montero*.
     - **Cochabamba:** Prefijo `4-` o `04-`, zonas: *Cala Cala*, *Quillacollo*, *Sacaba*, *Av. Blanco Galindo*.
     - **Oruro:** Prefijo `52-` o `2-52`, zonas: *Casco del Minero*, *Av. 6 de Agosto*.
     - **Potosí:** Prefijo `62-` o `2-62`.
     - **Tarija:** Prefijo `66-` o `4-66`.
  4. Si los registros bajo una cabecera de "ORURO" contienen teléfonos `64-` o direcciones de Chuquisaca, anular la cabecera visual del PDF y generar el encabezado correcto en Markdown:
     ```markdown
     ### Lista de Talleres – Sucre (Chuquisaca)

     | Taller | Dirección | Teléfono | Especialidad |
     | --- | --- | --- | --- |
     | Taller Central Sucre | Av. Jaime Mendoza Nro. 450 | 64-51234 | Mecánica General |
     | Auto Servicios San José | Barrio San José Calle 2 | 64-67890 | Chapistería y Pintura |
     ```

---

## Consolidado del SKILL: Prompt Maestro para el Motor / Agente de Extracción Docling Table-Aware

```markdown
# PROMPT DE INSTRUCCIÓN: SKILL DE EXTRACCIÓN MAESTRA DE TABLAS (TABLE-AWARE FOR DOCLING - CREDINFORM)

Actúa como un experto en visión por computadora e ingeniería de prompts de extracción de datos. Tu tarea es diseñar un skill de procesamiento de texto estructurado para el motor de extracción 'Docling' con enfoque 'Table-Aware'. Este skill debe aplicarse en la extracción de PDFs altamente complejos de pólizas de seguros. Debes obligar al motor a cumplir estrictamente las siguientes directivas de reconstrucción tabular:

1. DETECCIÓN BORDERLESS (SIN BORDES):
- Identifica alineaciones de columnas implícitas en áreas clave-valor.
- Proyecta una cuadrícula virtual para agrupar campos contiguos (como Datos del Asegurado a la izquierda y Datos del Tomador a la derecha) en tablas unificadas de 3 columnas en lugar de aplanar el texto o generar micro-tablas desconectadas.

2. BLOQUEO DE FILA CONTRA SALTOS DE LÍNEA (ROW-LOCKING):
- Si el texto de una celda de descripción de cobertura hace un "text wrap" (ocupa varios renglones), fusiónalo en un solo bloque de texto continuo mediante espacios en Markdown.
- Prohibido crear filas Markdown vacías o desplazar verticalmente valores de columnas adyacentes. Un renglón de texto largo NO equivale a una nueva fila de datos numéricos.

3. SOPORTE DE ENCABEZADOS MULTINIVEL:
- Para baremos o tablas con columnas comparativas (ej. Miembro Dominante vs. No Dominante), detecta la jerarquía de las cabeceras y consolida las etiquetas secundarias en la primera fila de encabezado de Markdown para asegurar que las columnas de datos se alineen correctamente.

4. PREVENCIÓN DE TRUNCAMIENTO OCR (EXPANSIÓN DE BOUNDING BOX):
- Configura las cajas de recorte de texto con un padding lateral mínimo para evitar la pérdida de letras en los bordes de la celda (ej. evitar que 'Cochabamba' sea recortado a 'Cochabamb' o valores como '1,000.00' a '100000').

5. VALIDACIÓN GEOGRÁFICA CONTEXTUAL:
- Al procesar listas de talleres, verifica las direcciones y códigos de área telefónica contra una base geográfica nacional básica (ej. Bolivia: prefijo 3 = Santa Cruz, 4 = Cochabamba, 2 = La Paz, 64 = Sucre). Corrige o separa las secciones de la tabla de talleres si el PDF original tiene errores de maquetación o títulos duplicados.
```

## Notas de Análisis

Observaciones generales sobre la estructura y formato de los documentos de esta empresa.
Agregar notas cada vez que se identifique un patrón nuevo, independientemente del archivo analizado.

- [x] Eliminación del pie de página institucional multicolumna (Oficina Principal Calacoto, Sucursal 1 Ravelo, contactos y sucursales regionales en Santa Cruz, Cochabamba, Sucre, Potosí, Oruro, Tarija, Camiri, Yacuiba, Trinidad).
- [x] Identificación y extracción de metadatos de póliza (Tomador, Asegurado, Número de Póliza) en encabezados repetitivos de páginas en documentos PDF escaneados (Condicionados Particulares).
- [x] Agregada lista de `kv_keys` específicos para campos de cabecera de pólizas CRI (`Asegurado`, `Tomador`, `Nro. NIT`, `Dirección`, `Cilindrada`, `Placa`, `Propiedad`, `Plaza de Circulación`, `Marca`, `Modelo`, etc.).
- [x] **Corrección de fugas de delimitadores y mezcla de columnas (Tabular Leakage):**
  - **Sub-tarea A (Prefijos basura en filas de tablas):** Eliminación de secuencias residuales como `\d+\s*\.-\s*,\s*` al inicio de celdas (ej. `| 1 .- , IVAN FERNANDO NATANAEL PICARDI |` $\rightarrow$ `| IVAN FERNANDO NATANAEL PICARDI |`).
  - **Sub-tarea B (Sufijos de tasas 'NT' y prefijo 'CI.' en documentos de identidad):** Limpieza de celdas de identificación con sufijo flotante `NT` (ej. `| CI. 18207 NT |` $\rightarrow$ `| 18207 |`, `| 6232690 NT |` $\rightarrow$ `| 6232690 |`).
  - **Sub-tarea C (Corrección de truncamiento OCR en talleres y nombres):** Limpieza de cadenas recortadas (`SERVICICO MECANIC`, `ANDRÉS CABALLE`, `Punto Axz`).
  - **Sub-tarea D (Separación de email y celular):** Desacoplamiento de emails y números telefónicos fusionados en una sola celda.
- [x] **Eliminación de ruido de maquetación y reconstrucción de tablas:**
  - Supresión de encabezados de póliza intermedios (`SERVICIOS PETROLEROS PONEX S.R.L CAC-SCE0651635`).
  - Supresión de filas de metadatos/tablas vacías (`Asegurado: | | | |`).
  - Supresión de números de página intermedios (`Página X de Y`).
  - **Reconstrucción de flujo continuo:** Cuando el ruido de maquetación divide una tabla a la mitad, se eliminan las líneas intrusivas y se unen las filas de la tabla de forma continua y sin rupturas.
- [x] **Arquitectura de Pipeline en 3 Fases:**
  1. *Fase 1 (Sustitución Determinista):* Regex para barrer patrones exactos de maquetación (páginas, encabezados, metadatos vacíos).
  2. *Fase 2 (Sustitución de Tablas):* Regex específicas para celdas de tablas (prefijos basura, sufijos NT en C.I., truncamientos OCR de talleres y separación email/celular).
  3. *Fase 3 (Refinamiento Semántico):* Reconstrucción del flujo Markdown continuo, resolución de guiones de fin de línea, unificación de tablas huérfanas y alineación multinivel.
- [x] **Integración Table-Aware y Tratamiento de Fallos Específicos (v6):**
  - **Fallo 1 (Borderless Grid):** Proyección de grilla virtual 3 columnas para Asegurado/Tomador y Datos Técnicos del Vehículo sin pérdida clave-valor.
  - **Fallo 2 (Row-Locking):** Fusión de textos multilínea en coberturas evitando desplazamiento vertical de sumas (`177,584.40`) y límites RC (`210,000.00`).
  - **Fallo 3 (Encabezados Multinivel):** Soporte de tablas de baremo e invalidez con subcolumnas Dominante/No Dominante.
  - **Fallo 4 (OCR Padding & Precisión):** Padding de 3-5px y preservación de precisión a dos decimales (`4,439.61`).
  - **Fallo 5 (Metadata Geográfica):** Validación cruzada de zonas y prefijos telefónicos (`64-` para Sucre) corrigiendo encabezados erróneos de Oruro en talleres.

## Historial de Cambios

| Versión | Fecha | Cambio |
|---------|-------|--------|
| 6 | 2026-09-02 | Integración de directivas maestras Table-Aware para Docling y resolución de 5 fallos críticos: extracción de tablas borderless en 3 columnas (Asegurado/Tomador/Vehículo), bloqueo de fila multilínea (row-locking en coberturas), encabezados multinivel para baremos de invalidez, prevención de truncamiento OCR con padding y reglas de limpieza, y validación contextual geográfica de talleres (Sucre vs. Oruro) |
| 5 | 2026-08-26 | Adición de reglas de limpieza tabular (`table_cell_cleanup_rules` para prefijos basura y sufijos NT en C.I.), eliminación de ruido de maquetación Ponex/CRI, patrones de reconstrucción de tablas divididas y especificación del pipeline de 3 fases |
| 4 | 2026-08-25 | Agregados `kv_keys` específicos para Credinform y regla `header_metadata_patterns` para extraer tomador/asegurado y número de póliza desde encabezados repetitivos |
| 3 | 2026-07-30 | Actualizados patrones de eliminación de pie de página institucional (Sucursal 1, direcciones, emails y teléfonos de sucursales) |
| 2 | 2026-07-30 | Agregados patrones de eliminación de encabezado institucional (Oficina Central / Central Piloto) |
| 1 | 2026-07-30 | Creación de plantilla inicial |